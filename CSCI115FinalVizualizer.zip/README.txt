READ ME FIRST (PLAIN TEXT)

This package contains:
- CMake project with src/ skeleton (headers + minimal main.cpp)
- maps/sample_small.txt (valid example map)
- docs/*.txt (plain text write-ups suitable for copy/paste into Canvas)

Open in CLion, set Working Directory to $ProjectFileDir$, and build target 'app'.
